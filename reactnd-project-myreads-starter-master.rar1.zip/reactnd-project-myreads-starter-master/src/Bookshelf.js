import React from 'react'



class BookShelf extends React.component{


    render(){

        return(

        <div className="bookshelf">
            <h2 className="bookshelf-title">(this.props.shelf.title)</h2>
            <div className="bookshelf-books">
            <ol className="books-grid">
            {this.props.data.map((book,index) =>
              <book key={index}  book={book}  
               books={this.props.data}
                shelfe={this.props.shelf} 
                onChange={this.props.onChange}/>
                )}
                
                

                </ol>
                </div>
                </div>  

    )}
    }
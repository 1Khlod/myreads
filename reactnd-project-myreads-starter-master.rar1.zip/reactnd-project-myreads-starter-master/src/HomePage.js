import React from 'react'
import ListBooks from './ListBooks'
import { Link } from 'react-router-dom'


class HomePage extends React.coponent{


    render(){

        const ShelfTypes =[{
            type: 'currentlyReading', title: 'currently Reading',
            type: 'WantToRead', title: 'Want To Read ',
            type: 'Read', title: 'Read',

        }]
    
    return(
        <div className = "list-books">
       
       <div className = "list-books-title">
          <h1>My Reads</h1>
       </div>

       <div className = "list-books-content">
       </div>
   <div>
   {ShelfeTypes.map((shelf,index)=>{
       let shelfeBooks = this.props.date.filter(book => book.shelf === shelf.type)
       return (<BookShelf data={ shelfeBooks}
               shelf={shelf}
               key={index}
               onChange= {this.props.onChange}/>)
   })}
   
   

   <div className "open-search">

    <Link to "/search"> Add a book </Link>

     </div>

    
    )}}

export default HomePage
    
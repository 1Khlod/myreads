import React from 'react'
 import * as BooksAPI from './BooksAPI'
import './App.css'
import HomePage from './HomePage.js'
import searchpage from './searchpage.js'
import {Route} from 'react-router-dom'
import {BrowserRouter} from 'react-router-dom'

class BooksApp extends React.Component {

  state = {

    book:[]

  }
  
  render() {
    return (
      <div className="app">
        {this.state.showSearchPage ? (
          <searchpage/>

     ) : (
     
          <ListofBooks/>
 
     )
      }
  </div> }

    
    
    
    componentDidMount() {
      BooksAPI.getAll().then((allBooks) => {
        console.log(allBooks)
        this.setState({
          books: allBooks
        })
      })
    }
  
  }
export default App
